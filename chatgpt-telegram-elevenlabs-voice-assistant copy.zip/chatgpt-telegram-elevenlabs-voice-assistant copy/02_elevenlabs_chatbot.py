#!/usr/bin/env python
#import pinecone
import telegram
from telegram.ext import Updater, MessageHandler, Filters
import openai
from moviepy.editor import AudioFileClip
from elevenlabslib import *

# Rest of your script...
# [Optional] pinecone.init(api_key="YOUR PINECONE API KEY", environment="YOUR ENVIRONMENT")  # replace YOUR_ENVIRONMENT with the appropriate environment
openai.api_key = "YOUR OPEN API KEY"
TELEGRAM_API_TOKEN = "YOUR TELEGRAM API TOKEN"
ELEVENLABS_API_KEY = "YOUR ELEVEN LABS API KEY"




#Initzialize Pine Cone
index_name = "YOUR INDEX NAME"
if index_name not in pinecone.list_indexes():
 pinecone.create_index(index_name, dimension=1536)  # replace 1536 with the dimension of your vectors

    
    # Dummy function: Replace with your own vector generation logic
def text_to_vector(text):
    return [1] * 1536





user = ElevenLabsUser(ELEVENLABS_API_KEY)
# This is a list because multiple voices can have the same name
# ... (previous code)
# Define 'voice' as a global variable before any function
voice = None  # Declare the variable before the try block

try:
    voices = user.get_voices_by_name("Rachel")
    if not voices:
        print("No voices found with the name 'Rachel'")
    else:
        voice = voices[0]
except Exception as e:
    print(f"An error occurred: {e}")
    voice = None  # Initialize voice to None in case of an error

# Define the messages list outside of any function
messages = [{"role": "system", "content": "You are a friendly professional assistant that starts its response by referring to the user as David."}]

def text_message(update, context):
    global voice  # Declare voice as a global variable
    # Convert the message text to a vector
    vector = text_to_vector(update.message.text)
    index = pinecone.Index(index_name)
    upsert_response = index.upsert(vectors=[(str(update.message.message_id), vector)])
    update.message.reply_text(
        "One moment :)")
    messages.append({"role": "user", "content": update.message.text})
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=messages
    )
    response_text = response["choices"][0]["message"]["content"]
    messages.append({"role": "assistant", "content": response_text})
    if voice:  # Check if voice is not None
        response_byte_audio = voice.generate_audio_bytes(response_text)
        with open('response_elevenlabs.mp3', 'wb') as f:
            f.write(response_byte_audio)
        context.bot.send_voice(chat_id=update.message.chat.id,
                               voice=open('response_elevenlabs.mp3', 'rb'))
    update.message.reply_text(
        text=f"*[Bot]:* {response_text}", parse_mode=telegram.ParseMode.MARKDOWN)

def voice_message(update, context):
    global voice  # Declare voice as a global variable
    update.message.reply_text(
        "One moment :)")
    voice_file = context.bot.getFile(update.message.voice.file_id)
    voice_file.download("voice_message.ogg")
    audio_clip = AudioFileClip("voice_message.ogg")
    audio_clip.write_audiofile("voice_message.mp3")
    audio_file = open("voice_message.mp3", "rb")
    transcript = openai.Audio.transcribe("whisper-1", audio_file).text
    update.message.reply_text(
        text=f"*[You]:* _{transcript}_", parse_mode=telegram.ParseMode.MARKDOWN)
    messages.append({"role": "user", "content": transcript})
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=messages
    )
    response_text = response["choices"][0]["message"]["content"]
    messages.append({"role": "assistant", "content": response_text})
    if voice:  # Check if voice is not None
        response_byte_audio = voice.generate_audio_bytes(response_text)
        with open('response_elevenlabs.mp3', 'wb') as f:
            f.write(response_byte_audio)
        context.bot.send_voice(chat_id=update.message.chat.id,
                               voice=open('response_elevenlabs.mp3', 'rb'))
    update.message.reply_text(
        text=f"*[Bot]:* {response_text}", parse_mode=telegram.ParseMode.MARKDOWN)



updater = Updater(TELEGRAM_API_TOKEN, use_context=True)
dispatcher = updater.dispatcher
dispatcher.add_handler(MessageHandler(
    Filters.text & (~Filters.command), text_message))
dispatcher.add_handler(MessageHandler(Filters.voice, voice_message))
updater.start_polling()
updater.idle()




